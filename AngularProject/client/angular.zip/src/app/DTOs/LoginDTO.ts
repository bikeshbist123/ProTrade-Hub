export interface LoginDTO {

  username : string;
  password : string;
}
